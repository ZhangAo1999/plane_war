import pygame


class Bullet:
    def __init__(self, x, y, screen):
        # 玩家子弹的出现位置
        self.x = x + 26
        self.y = y - 30
        # 赋值screen
        self.screen = screen
        # 加载子弹的图片对象。
        self.image = pygame.image.load("./feiji/bullet.png").convert()

    # 显示子弹
    def display(self):
        self.screen.blit(self.image, (self.x, self.y))

    # 子弹移动
    def move(self):
        self.y -= 12

    # 判断是否已经移出屏幕
    def judge(self):
        if self.y < 0:
            return True
        return False


class EnemyBullet:
    def __init__(self, x, y, screen):
        # 类似玩家子弹，但因为敌人有两种，所以敌人子弹也有两种。
        self.x = x + 30
        self.y = y + 80
        self.screen = screen
        self.image = pygame.image.load("./feiji/bullet1.gif").convert()
        self.image1 = pygame.image.load("./feiji/bullet.gif").convert()

    def move(self):
        self.y += 2

    def display(self):
        self.screen.blit(self.image, (self.x, self.y))

    def display1(self):
        self.screen.blit(self.image1, (self.x, self.y))

    def judge(self):
        if self.y > 700:
            return True
        return False
