from pygame.locals import *
from plane import *


# 检测按键操作
def key_down(hero_plane):
    # 如果事件类型为QUIT，即按了叉子，就退出程序。
    for event in pygame.event.get():
        if event.type == QUIT:
            exit()
    # 用key_pressed来接收当前时刻哪个键被按下了，这样就可以同时检测多个按键，并且可以连续检测。
    key_pressed = pygame.key.get_pressed()
    # 分别调用飞机的移动和射击的方法
    if key_pressed[pygame.K_a] or key_pressed[pygame.K_LEFT]:
        hero_plane.move_left()
    if key_pressed[pygame.K_d] or key_pressed[pygame.K_RIGHT]:
        hero_plane.move_right()
    if key_pressed[pygame.K_w] or key_pressed[pygame.K_UP]:
        hero_plane.move_up()
    if key_pressed[pygame.K_s] or key_pressed[pygame.K_DOWN]:
        hero_plane.move_down()
    if key_pressed[pygame.K_SPACE]:
        hero_plane.launch_bullet()


# 在页面上显示文字。
def wenzi(screen, string, time=50):
    # 加载已经下载的本地字体。
    font = pygame.font.Font("./ziti/zi_ti.ttf", 20)
    # 设置文字的位置
    x, y = 30, 500
    # 将文字逐个展示在页面上
    for i in str(string):
        # 首先要将他转化成screen可以识别的样式。
        font_fmt = font.render(i, 1, (0, 0, 0), (255, 255, 255))
        # 然后像显示图片一样显示文字。
        screen.blit(font_fmt, (x, y))
        # 每显示一个字x坐标向右偏移25。
        x += 25
        # 如果文字显示满一行了，将y坐标向下偏移40，同时x重新变成30。
        if x > 370:
            y += 40
            x = 30
        # 更新界面上的显示
        pygame.display.update()
        # 让线程休眠time毫秒。time默认为50,也就是说每50毫秒蹦一个字儿。
        pygame.time.delay(time)


# 显示一个简短的剧情。
def juqing1(screen, background):
    # words表示剧情中怪物需要说的话。
    words = ["天亮了。。。", "要出去狩猎了啊？", "咦？", "你是被他们，那群村民找来送死的吗？", "你这样的冒险者我见多了，不过他们都死了。我送你去陪他们吧！"]
    # i在之后的循环中代表当前说的是第几句话。
    i = 0
    # need_view代表每句话是否已经显示过了。
    need_view = [True, True, True, True, True]
    while True:
        # 先贴背景，把之前的杂七杂八的覆盖掉。
        screen.blit(background, (0, 0))
        # 给敌人的立绘和文本框加载好，方便在screen上建立。
        lihui_enymy_path = "./feiji/enemy_3D.gif"
        lihui_enymy = pygame.image.load(lihui_enymy_path).convert()
        borad_path = "./feiji/white.png"
        borad = pygame.image.load(borad_path).convert()
        # 在screen上建立敌人的立绘和文本框。
        screen.blit(lihui_enymy, (10, 340))
        screen.blit(borad, (10, 480))
        # 如果当前的文字还没显示过，
        if need_view[i]:
            # 正常50ms蹦一个字，并将need_view[i]设成False
            wenzi(screen, words[i])
            need_view[i] = False
        # 否则，
        else:
            # 将time设成0，也就是一瞬间让所有字全显示出来。
            wenzi(screen, words[i], 0)
        # 检测是否按键，按键则将i+1，也就是显示下一行文字。也就是说，如果不按键，并且上面没有设置time=0的区别的话，他每次都会一个一个字地蹦。
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                i = i + 1
            elif event.type == QUIT:
                print("exit")
                exit()
        # 如果i>4，也就是5句话全显示完了，就跳出循环，也就是说剧情结束。
        if i > 4:
            break
        # 等待按键的休眠设为200ms
        pygame.time.delay(200)
        pygame.display.update()


# 和剧情1类似，几乎是直接复制粘贴的。
def juqing2(screen, background, hero_plane):
    # 加载一张第一个背景被第二个背景撕裂的图background_error
    # 加载飞机和震惊（3个！）
    background_error_path = "./feiji/background_error.png"
    background_error = pygame.image.load(background_error_path).convert()
    image_name = "./feiji/hero.gif"
    hero_plane_image = pygame.image.load(image_name).convert()
    shock_path = "./feiji/shock.gif"
    shock = pygame.image.load(shock_path).convert()
    # 在界面上显示background_error，飞机，并在飞机的右上角的位置显示3个！代表震惊
    screen.blit(background_error, (0, 0))
    screen.blit(hero_plane_image, (hero_plane.x, hero_plane.y))
    screen.blit(shock, (hero_plane.x + 60, hero_plane.y - 40))
    pygame.display.update()
    # 休眠2秒
    pygame.time.delay(2000)
    while True:
        # 这个循环是用来检测是否按键，如果按键就退出刚刚那个页面，继续其他剧情的。
        flag = False
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                flag = True
            elif event.type == QUIT:
                print("exit")
                exit()
        if flag:
            break
        pygame.time.delay(200)
    # 下面是不是很熟悉啊？跟剧情1就几乎一模一样了。
    words = ["今天的黑夜，来得格外的早啊。。。", "是你灭掉了那个种族吗？", "这样这个世界就会一直被黑夜笼罩了啊，你连这个都不懂吗？！", "空有这么强大的力量，不知道要保持生态的平衡吗？", "那就感受绝望吧！！"]
    i = 0
    need_view = [True, True, True, True, True]
    while True:
        screen.blit(background, (0, 0))
        lihui_enymy_path = "./feiji/enemy1_3D.gif"
        lihui_enymy = pygame.image.load(lihui_enymy_path).convert()
        borad_path = "./feiji/white.png"
        borad = pygame.image.load(borad_path).convert()
        # 在第几行输出相应文字。
        screen.blit(lihui_enymy, (10, 340))
        screen.blit(borad, (10, 480))
        if need_view[i]:
            wenzi(screen, words[i])
            need_view[i] = False
        else:
            wenzi(screen, words[i], 0)
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                i = i + 1
            elif event.type == QUIT:
                print("exit")
                exit()
        if i > 4:
            break
        pygame.time.delay(200)
        pygame.display.update()


# 游戏开始
def start():
    # 好像不写这句的话没法显示出文字来。
    pygame.init()
    # fen_l用来存储分数的图片的路径
    fen_l = []
    # fen_list用来存储加载好的分数图片对象。
    fen_list = []
    # 初始化界面。
    screen = pygame.display.set_mode((400, 700), 0, 32)
    # 一个for循环，将分数0到9的图片存放到fen_l和fen_list中。
    for i in range(10):
        fen_l.append("./feiji/score"+str(i)+".gif")
        fen_list.append(pygame.image.load(fen_l[i]).convert())
    # 将加号也存放到fen_list中。
    fen_list.append(pygame.image.load("./feiji/add.gif").convert())
    # 加载默认背景，夜晚，沙滩，游戏失败，游戏开始等需要用到的图片。
    image_file_path = './feiji/background.png'
    image_file_path1 = './feiji/background_night.png'
    image_file_path2 = './feiji/background_beach.png'
    image_file_path3 = './feiji/game_over.gif'
    image_file_path4 = './feiji/start.gif'
    background = pygame.image.load(image_file_path).convert()
    background_night = pygame.image.load(image_file_path1).convert()
    background_beach = pygame.image.load(image_file_path2).convert()
    game_over = pygame.image.load(image_file_path3).convert()
    sta = pygame.image.load(image_file_path4).convert()
    # 创建一个玩家飞机的对象。
    hero_plane = HeroPlane(screen)
    # 创建一个敌人飞机的列表。
    enemy_plane_list = []
    # 这个是一个大列表，里边嵌套7个小列表，代表分数还要在屏幕上显示多少个50ms
    # 每个小列表里存放的是n个元组，包含死亡的敌机的分数，和它的xy坐标。
    # 这个列表在某1ms可能形如fen_dict = [[],[],[],[(12000, 20, 200)],[],[],[(11000, 100, 300), (10000, 200, 200)]]
    # 代表一架飞机已经被击毁3*50ms了，还有两架飞机刚被击毁
    # 那么50ms之后，不考虑新坠毁的敌机的话，fen_dict会变成
    # [[],[],[(12000, 20, 200)],[],[],[(11000, 100, 300), (10000, 200, 200)], []]
    # 即一架飞机已经被击毁4*50ms,还有两架飞机已经被击毁1*50ms
    fen_dict = [[], [], [], [], [], [], []]
    # i每次循环加1，用来代表多久出一个怪，这里设置的是如果i%43==0就出怪，也就是43*50ms出一个怪。
    i = 0
    # 一个juqing列表代表是否看过2个剧情，如果看过的话，game_over后重开就不会再显示了。
    juqing = [False, False]
    # 判断玩家是否为死亡状态。
    dead = False
    # 统计分数。
    score = 0
    while True:
        # 一个循环，卡在开始页面，只显示背景和start的文本，按任意键后跳出循环。
        screen.blit(background, (0, 0))
        screen.blit(sta, (30, 280))
        pygame.time.delay(200)
        pygame.display.update()
        st = False
        for event in pygame.event.get():
            if event.type == KEYDOWN:
                st = True
            elif event.type == QUIT:
                print("exit")
                exit()
        if st:
            break
    # 真正游戏开始。
    while True:
        # 一个敌人子弹的列表。
        bad_bullet_list = []
        # 如果玩家阵亡，
        if dead:
            # 显示沙滩背景，最终分数和game_over图片
            screen.blit(background_beach, (0, 0))
            screen.blit(game_over, (30, 340))
            fenshu = pygame.font.Font("./ziti/zi_ti.ttf", 36)
            fenshu = fenshu.render("分数：" + str(score), 1, (0, 0, 0))
            screen.blit(fenshu, (60, 280))
            for event in pygame.event.get():
                # 直到检测按键后重开，
                if event.type == KEYDOWN:
                    # 将分数初始化为0，玩家也重新创建，敌人列表设为空，i重置为0，死亡的状态修改为False。
                    score = 0
                    hero_plane = HeroPlane(screen)
                    enemy_plane_list = []
                    i = 0
                    dead = False
                    # 为什么不用把敌人子弹的列表也设为空？因为我这里敌人的子弹是和飞机绑定的，敌人死了，他的子弹也就消失了。
                elif event.type == QUIT:
                    print("exit")
                    exit()
            pygame.display.update()
            pygame.time.delay(200)
            continue
        i += 1
        # 上面提到的43*50ms出一架敌机。
        if i % 43 == 1:
            # 也就是创建一个敌机对象，并加到敌机列表里。
            enemy_plane = EnemyPlane(screen)
            enemy_plane_list.append(enemy_plane)
        # 分数小于100万的话，
        if score < 1000000:
            # 如果没播放过剧情1
            if not juqing[0]:
                # 播放
                juqing1(screen, background)
                juqing[0] = True
            # 使用默认的蓝天白云背景
            screen.blit(background, (0, 0))
            # 将每个敌人用敌人默认样式显示出来，并将每个敌人的子弹放到敌人子弹列表中。
            for enemy_plane in enemy_plane_list:
                enemy_plane.display()
                bad_bullet_list.extend(enemy_plane.bullet_list)
        # 如果分数超过100万了，
        else:
            # 如果剧情2没播放过
            if not juqing[1]:
                # 播放剧情2
                juqing2(screen, background_night, hero_plane)
                juqing[1] = True
            # 使用夜晚背景
            screen.blit(background_night, (0, 0))
            # 将每个敌人用敌人样式1显示出来，并将每个敌人的子弹放到敌人子弹列表中。
            for enemy_plane in enemy_plane_list:
                enemy_plane.display1()
                bad_bullet_list.extend(enemy_plane.bullet_list)
        # 用一个列表来存放死亡的敌机。
        dead_enemy_list = []
        # 遍历敌机列表
        for enemy_plane in enemy_plane_list:
            # 用一个列表来存取需要删除的玩家子弹。
            del_bullet_list = []
            # 遍历玩家所有子弹
            for hero_bullet in hero_plane.bullet_list:
                # 敌机的is_hurt方法会检测是否与玩家的子弹有接触，如果有就将该子弹放到需要删除的子弹列表里，同时给该敌机减血。
                # 用win来接收返回值，返回值种类较多，咱们去具体的类里看看吧。
                win = enemy_plane.is_hurt(hero_bullet)
                # 如果win[0]==0，代表当前子弹没击中当前敌机
                if win[0] == 0:
                    continue
                # 如果win[0]==1代表击中并且击毁了当前敌机。
                if win[0] == 1:
                    # 这颗子弹放到要删除的子弹列表中。
                    del_bullet_list.append(win[1][1])
                    # 如果这架敌机不在死亡敌机的列表里，将它加进去。并将分数加上这架敌机的分数。
                    # fen_dict[6]里添加一个分数和对应坐标。即这个分数还要在这里显示6*50ms
                    if win[1][0] not in dead_enemy_list:
                        dead_enemy_list.append(win[1][0])
                        score += win[2]
                        fen_dict[6].append((win[2], win[1][0].x, win[1][0].y))
                # 如果win[0]==2，代表击中敌机但没打死，就只需要将子弹放入需要删除的子弹的列表就可以了。
                if win[0] == 2:
                    del_bullet_list.append(win[1])
            # 将需要删除的子弹删除。之所以将敌机的循环放在子弹的循环外面，就是为了让子弹只可能打中一个敌人。
            for del_bullet in del_bullet_list:
                hero_plane.bullet_list.remove(del_bullet)

        # 将死掉的敌机从敌机列表里删除。
        for dead_enemy in dead_enemy_list:
            enemy_plane_list.remove(dead_enemy)
        # 调用所有存活敌机的launch_bullet()方法，模拟发射子弹。
        # 虽然每50ms都执行一次这个方法，但因为只有5/100的几率添加子弹，所有其实弹幕不会太密。
        # 然后敌机移动。
        for enemy_plane in enemy_plane_list:
            enemy_plane.launch_bullet()
            enemy_plane.move()
        # 下面就是要显示分数了！

        # 首先还剩0秒的就随便再显示一下就行了。
        for j in fen_dict[0]:
            # fen_list[10]是加号（+）,位置就是元组里的飞机坠毁的位置向上偏移1点。
            # 这里的偏移1点其实是先+20，再-21.因为我规定的是从飞机坠毁位置的起始点向下20个单位长度的地方开始显示分数的。
            # 然后每50ms向上偏移3个单位长度，于是7*50ms后，就向上偏移了21，就相当于从起始向上偏移了1.
            screen.blit(fen_list[10], (j[1], j[2] - 1))
            # 定义一个x坐标的偏移量，以免加号和分数显示重叠。
            x = 30
            for fen in str(j[0]):
                # 把分数的每个字符分别显示，fen_list列表的索引对应的就是每个数字的图片对象。
                screen.blit(fen_list[int(fen)], (j[1] + x, j[2] - 1))
                # y坐标不变，x向右18个单位长度，以免数字与数字之间重叠。
                x += 18
        # 将fen_dict[0]置空，代表此列表的分数显示完毕！
        fen_dict[0] = []
        # 然后从fen_dict[1]到fen_dict[6]循环，用k表示第几层。
        for k in range(1, 7):
            for j in fen_dict[k]:
                # y轴偏移量用飞机坠毁的y坐标+20再-(7-k)*3，让它能保持一个上升的趋势。
                screen.blit(fen_list[10], (j[1], j[2] + 20 - (7-k) * 3))
                # x轴处理同上。
                x = 30
                for fen in str(j[0]):
                    screen.blit(fen_list[int(fen)], (j[1] + x, j[2] + 20 - (7-k) * 3))
                    x += 18
                # 比较关键的一点，如果实现时间的变化呢？
                # 在k-1中添加进k的所有项，不用担心索引越界，因为k为0的情况已经在前面处理了。
                fen_dict[k-1].append(j)
            # 添加完之后，将第k列表置空。
            fen_dict[k] = []
        # 检测一下玩家有没有被击中，同样是写了一个is_hurt方法，传进的参数是敌人的子弹列表。
        hero_hurt = hero_plane.is_hurt(bad_bullet_list)
        if hero_hurt:
            # 如果没血了，dead就是True了。
            if hero_hurt == "game over":
                dead = True
            else:
                # 否则，返回的变量是攻击到玩家的子弹，将它从敌机的子弹中移出！
                for enemy_plane in enemy_plane_list:
                    if hero_hurt in enemy_plane.bullet_list:
                        enemy_plane.bullet_list.remove(hero_hurt)
        hero_plane.display()
        # 在左上角显示分数。
        x = 0
        for fen in str(score):
            # 同样是一个一个数字的来，每次x向右偏移18个单位长度。
            screen.blit(fen_list[int(fen)], (x, 0))
            x += 18
        # 调用上方的检测按键方法。
        key_down(hero_plane)
        # 线程休眠50ms
        pygame.time.delay(50)
        # 更新显示画面。
        pygame.display.update()


start()


