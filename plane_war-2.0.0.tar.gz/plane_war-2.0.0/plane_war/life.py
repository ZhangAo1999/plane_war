import pygame


class Life:
    def __init__(self, screen):
        # 显示生命值的位置。
        self.x = 400 - 28 * 4
        self.y = 0
        self.screen = screen
        # 初始血量和当前血量。
        self.init_blood = 4
        self.now_blood = 4
        # 血的有和空的图片对象。
        self.blood = pygame.image.load("./feiji/blood.png").convert()
        self.blood1 = pygame.image.load("./feiji/blood1.png").convert()

    def hurt(self):
        # 如果受伤，当前血量减一，如果死亡返回True。
        self.now_blood -= 1
        if self.now_blood == 0:
            return True
        return False

    def display(self):
        # i从0到当前血量显示有血，
        for i in range(self.now_blood):
            self.screen.blit(self.blood, (self.x, self.y))
            self.x += 28
        # 剩下的显示空血。
        for i in range(self.init_blood - self.now_blood):
            self.screen.blit(self.blood1, (self.x, self.y))
            self.x += 28
        self.x = 400 - 28 * 4
