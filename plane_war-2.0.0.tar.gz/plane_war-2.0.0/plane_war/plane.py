import pygame
from bullet import Bullet, EnemyBullet
from random import randint
from life import Life


class HeroPlane:
    t = 0

    def __init__(self, screen):
        # 玩家起始位置
        self.x = 230
        self.y = 500
        # 将screen赋值给玩家飞机的screen
        self.screen = screen
        # 加载玩家飞机的两张图片，形成火焰在喷射的动态效果
        self.image_name = "./feiji/hero.gif"
        self.image_name1 = "./feiji/hero1.gif"
        self.image = pygame.image.load(self.image_name).convert()
        self.image1 = pygame.image.load(self.image_name1).convert()
        # 一个计数器。
        self.t = 0
        # 玩家的子弹列表
        self.bullet_list = []
        # 玩家的受创范围
        self.bload = []
        # 一个包含70个列表的列表。
        for i in range(70):
            self.bload.append([])
        # 玩家的生命是一个生命类。
        self.life = Life(screen)
        # 每个列表包含76项，初始全为False。因为玩家的飞机是70*76的。
        # 可以把它想象成一个[70][76]的二维数组。
        for i in range(70):
            for j in range(76):
                self.bload[i].append(False)
        # 调用自身的block方法，将可被击中范围设成True。
        self.block()
        self.bullet = pygame.mixer.Sound("./sound/bullet.ogg")
        self.bullet.set_volume(0.4)

    # 判断玩家是否被击中已经是否死亡。
    def is_hurt(self, bad_bullet_list):
        for bad_bullet in bad_bullet_list:
            # 检测敌机的每一颗子弹，如果与玩家的坐标相减会越界的话，直接检测下一颗
            if bad_bullet.x - self.x < 0 or bad_bullet.x - self.x > 69 or bad_bullet.y - self.y < 0 or bad_bullet.y - self.y >75:
                continue
            # 如果飞机的这个部位的确可以被击中的话，
            if self.bload[bad_bullet.x - self.x][bad_bullet.y - self.y]:
                # 调用飞机的生命的hurt方法，如果没死，
                if not self.life.hurt():
                    # 返回那颗子弹，一会儿将它删除。
                    return bad_bullet
                # 否则，即死了。
                else:
                    # 返回game over。
                    return "game over"
        # 如果所有子弹都没击中玩家，返回空。
        return None

    # 简单把飞机分成3块，以飞机的x, y为参照点，这3个范围可以被击中。
    # 这三块分别是机头，机翼，机尾
    # (32, 0)->(37, 17)
    # (0, 25)->(70, 46)
    # (20, 46)->(52, 63)
    # 只有这些部位被击中才会扣血，给玩家更多的躲避空间。
    def block(self):
        for i in range(32, 37):
            for j in range(0, 17):
                self.bload[i][j] = True
        for i in range(0, 70):
            for j in range(25, 46):
                self.bload[i][j] = True
        for i in range(20, 52):
            for j in range(46, 63):
                self.bload[i][j] = True

    # 检测x坐标是否在边缘，x坐标在边缘可以左右互相穿墙。
    def boundary_x(self):
        if self.x < -70:
            self.x = 400
        elif self.x > 400:
            self.x = -70

    # 检测y坐标是否在边缘，y坐标在边缘就不让继续走了。
    def boundary_y(self):
        if self.y < 0:
            self.y = 0
        if self.y > 624:
            self.y = 624

    # 玩家的发射子弹方法，同样是创建一个新的子弹对象，并加到玩家的子弹列表中。
    def launch_bullet(self):
        self.bullet.play()
        new_bullet = Bullet(self.x, self.y, self.screen)
        self.bullet_list.append(new_bullet)

    # 玩家的显示方法。
    def display(self):
        # 如果t对10取余小于5，显示默认图，否则显示图1，就实现了每5*50ms换一张图的动态效果。
        if HeroPlane.t % 10 < 5:
            self.screen.blit(self.image, (self.x, self.y))
        else:
            self.screen.blit(self.image1, (self.x, self.y))
        HeroPlane.t += 1
        # 如果t太大了，就减一个数继续计数。
        if HeroPlane.t > 1000000:
            HeroPlane.t -= 1000000
        # 定义一个需要删除的子弹的列表
        need_del_list = []
        # 调用子弹的judge方法，如果的确需要删除，就放到需要删除的列表。
        for item in self.bullet_list:
            if item.judge():
                need_del_list.append(item)
        for def_item in need_del_list:
            self.bullet_list.remove(def_item)
        # 将剩下的子弹显示出来，并移动。
        for bullet in self.bullet_list:
            bullet.display()
            bullet.move()
        # 显示下生命
        self.life.display()

    # 玩家的移动方法。
    def move_left(self):
        self.x -= 20
        self.boundary_x()

    def move_right(self):
        self.x += 20
        self.boundary_x()

    def move_up(self):
        self.y -= 20
        self.boundary_y()

    def move_down(self):
        self.y += 20
        self.boundary_y()


class EnemyPlane:
    def __init__(self, screen):
        # 敌机的x坐标是随机的，y是0。
        self.x = randint(80, 240)
        self.y = 0
        # 将screen赋值给自身的screen。
        self.screen = screen
        # 敌机有2种样式，有2个display方法。
        self.image_name = "./feiji/enemy.gif"
        self.image_name1 = "./feiji/enemy1.gif"
        self.image = pygame.image.load(self.image_name).convert()
        self.image1 = pygame.image.load(self.image_name1).convert()
        # 敌人的子弹集合
        self.bullet_list = []
        # 敌机的移动方向
        self.direction = "right" if randint(1, 2) == 1 else "left"
        # 敌机的生命，24-36随机的
        self.life = randint(24, 36)
        # 敌机的分数，1326-1570*敌机的生命值，将随机性进一步扩大、、
        self.score = self.life * randint(1326, 1570)
        # 代表本机的血量是否已经改变。
        self.flag = False
        self.get_score = pygame.mixer.Sound("./sound/get_score.ogg")
        self.get_score.set_volume(2)

    def move(self):
        # 每次移动向下偏移1坐标，并根据方向左右撞墙。
        self.y += 1
        if self.direction == "right":
            self.x += 6
        elif self.direction == "left":
            self.x -= 6
        if self.x > 300:
            self.direction = "left"
        elif self.x < 0:
            self.direction = "right"

    # 敌人的子弹方法
    def launch_bullet(self):
        number = randint(1, 100)
        # 有5/100的概率发射子弹。
        if number < 6:
            # 就是将子弹添加到子弹列表里。
            new_bullet = EnemyBullet(self.x, self.y, self.screen)
            self.bullet_list.append(new_bullet)

    # is_hurt，返回值种类很多的那个
    def is_hurt(self, bullet):
        # 如果玩家子弹的xy坐标与敌机的xy坐标之间相减没出界，就继续下一步判断。
        if 0 < bullet.x - self.x < 110 and 0 < bullet.y - self.y < 100:
            # 敌机的生命值减1
            self.life -= 1
            # 元组1由3个值组成,第一个1代表类型是1，第二个是一个元组，包含他本身这个对象和子弹对象，第三个是他的分数。
            return_1 = (1, (self, bullet), self.score)
            # 元组2由2个值组成，第一个2代表类型是2，第二个是返回子弹对象。
            return_2 = (2, bullet)
            # 如果敌机生命小于等于0，返回元组1
            if self.life <= 0:
                self.get_score.play()
                return return_1
            # 否则返回元组2
            return return_2
        # 出界了，就直接返回一个元组，第一个0代表类型是0，第2个0纯粹占位的。
        return_3 = (0, 0)
        # 返回元组3
        return return_3

    def display(self):
        # 显示一下默认样式的敌机
        self.screen.blit(self.image, (self.x, self.y))
        # need_del_list指的是需要删除的敌人的子弹
        need_del_list = []
        # 如果子弹出界了，就将他添到需要删除的子弹列表里
        for i in self.bullet_list:
            if i.judge():
                need_del_list.append(i)
        # 在bullet_list中删除需要删除的子弹。
        for i in need_del_list:
            self.bullet_list.remove(i)
        # 将剩下的子弹显示并让他们移动一下。
        for bullet in self.bullet_list:
            bullet.display()
            bullet.move()

    def display1(self):
        # 因为此时已经第二个场景了，怪物要加强，所以如果本机还未加强，将血量上升10，分数上升2万，并将flag设为True。
        if not self.flag:
            self.life += 10
            self.score += 20000
            self.flag = True
        # 显示样式1的敌机。
        self.screen.blit(self.image1, (self.x, self.y))
        # 以下同上
        need_del_list = []
        for i in self.bullet_list:
            if i.judge():
                need_del_list.append(i)
        for i in need_del_list:
            self.bullet_list.remove(i)
        for bullet in self.bullet_list:
            bullet.display1()
            bullet.move()
